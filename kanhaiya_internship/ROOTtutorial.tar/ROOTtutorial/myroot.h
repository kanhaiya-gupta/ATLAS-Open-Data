#ifndef myroot_h_
#define myroot_h_
#include "TROOT.h"
#include "TStyle.h"
#include "TF1.h"
#include "TF2.h"
#include "TH1D.h"
#include "TRandom3.h"
#include "TFile.h"
#include "TTree.h"
#include "TH2D.h"
#include "TString.h"
#include "TLegend.h"
#include "TMath.h"
#include "THStack.h"
#include "TCanvas.h"
#include <iostream>
using namespace std;

#endif
